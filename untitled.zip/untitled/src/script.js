function calculateBudget() {
  let income = parseFloat(document.getElementById("income").value) || 0;
  let downPayment =
    parseFloat(document.getElementById("downPayment").value) || 0;
  let monthlyDebt =
    parseFloat(document.getElementById("monthlyDebt").value) || 0;
  let agentCommission =
    parseFloat(document.getElementById("agentCommission").value) || 0;
  let otherCosts = parseFloat(document.getElementById("otherCosts").value) || 0;

  let interestRate = 0.065; // 6.5%
  let loanTerm = 30; // 30 years
  let maxMonthlyMortgage = (income / 12) * 0.42 - monthlyDebt;

  if (maxMonthlyMortgage <= 0) {
    document.getElementById("result").innerHTML =
      "Error: Monthly debt exceeds allowable limits. Adjust inputs.";
    return;
  }

  let monthlyRate = interestRate / 12;
  let totalPayments = loanTerm * 12;
  let loanAmount =
    maxMonthlyMortgage *
    ((1 - Math.pow(1 + monthlyRate, -totalPayments)) / monthlyRate);

  let totalBudget = loanAmount + downPayment - otherCosts;
  let commissionCost = totalBudget * (agentCommission / 100);
  let finalBudget = totalBudget - commissionCost;

  document.getElementById(
    "result"
  ).innerHTML = `Estimated Home Purchase Budget: $${finalBudget.toFixed(2)}`;
}
